A Pen created at CodePen.io. You can find this one at https://codepen.io/rishaldy-muhammad/pen/PVvZoM.

 Code from the article: http://www.sitepoint.com/build-javascript-clock-no-dependencies

Forked from [Yaphi](http://codepen.io/yaphi1/)'s Pen [Styled JavaScript Countdown Clock](http://codepen.io/yaphi1/pen/KpbRaE/).